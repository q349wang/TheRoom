#ifndef _GAME_CONSTANTS_H_
#define _GAME_CONSTANTS_H_

enum GameColours : int
{
    White = 0,
    Black = 1,
    Red = 2,
    OrangeRed = 3,
    Green = 4,
    Blue = 5,
    DarkGreen = 6,
    Purple = 7,
    Yellow = 8
};

#endif