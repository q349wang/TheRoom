#include "MapManager.h"

using namespace std;

void MapManager::populateMap(shared_ptr<Map> empty_map, int level) {
    
}